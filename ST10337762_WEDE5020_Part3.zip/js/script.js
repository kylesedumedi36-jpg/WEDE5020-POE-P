// This file contains the small interactive features used on the website.
document.addEventListener("DOMContentLoaded", function () {
  setupMobileMenu();
  setupMenuSearch();
  setupGallery();
  setupEnquiryForm();
  setupContactForm();
  fillEnquiryFromLink();
});

// Open and close the navigation menu on smaller screens.
function setupMobileMenu() {
  const menuButton = document.querySelector(".menu-toggle");
  const navigation = document.querySelector("#main-nav");

  if (!menuButton || !navigation) return;

  menuButton.addEventListener("click", function () {
    const isOpen = navigation.classList.toggle("is-open");
    menuButton.setAttribute("aria-expanded", String(isOpen));
  });
}

// Filter menu items as the visitor types in the search box.
function setupMenuSearch() {
  const searchInput = document.querySelector("#menu-search");
  const menuItems = document.querySelectorAll("[data-item]");
  const searchStatus = document.querySelector("#search-status");
  const noResults = document.querySelector("#no-results");

  if (!searchInput) return;

  searchInput.addEventListener("input", function () {
    const searchTerm = searchInput.value.trim().toLowerCase();
    let visibleCount = 0;

    menuItems.forEach(function (item) {
      const matches = item.textContent.toLowerCase().includes(searchTerm);
      item.hidden = !matches;
      if (matches) visibleCount += 1;
    });

    // Hide a whole category if none of its menu items match.
    document.querySelectorAll(".menu-card").forEach(function (card) {
      const hasVisibleItem = card.querySelector("[data-item]:not([hidden])");
      card.hidden = !hasVisibleItem;
    });

    searchStatus.textContent = visibleCount + " menu item(s) found.";
    noResults.hidden = visibleCount !== 0;
  });
}

// The four gallery categories each contain five photos. Image URLs point to ISO Republic.
const galleryCategories = {
  "cakes": [
    "Cakes",
    "Celebration cakes",
    "🎂",
    [
      [
        "Black Forest Cake",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-black-forest-cake-450x300.jpg"
      ],
      [
        "Cake Dessert",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-cake-dessert-3-450x300.jpg"
      ],
      [
        "Freshly Baked Cake",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-baked-cake-1-450x300.jpg"
      ],
      [
        "Strawberry Chocolate Cakes",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-strawberry-chocs-1-450x300.jpg"
      ],
      [
        "Cake and Coffee",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-coffee-cake-cafe-1-450x300.jpg"
      ]
    ]
  ],
  "pastries": [
    "Pastries",
    "Fresh pastries and muffins",
    "🥐",
    [
      [
        "Freshly Baked Pastries",
        "https://isorepublic.com/wp-content/uploads/2018/11/picography-fresh-baked-pastries-1-450x300.jpg"
      ],
      [
        "Bakery Pastries",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-bakery-pastries-450x300.jpg"
      ],
      [
        "Fresh Pastries",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-pastries-1-450x300.jpg"
      ],
      [
        "Cake Donuts",
        "https://isorepublic.com/wp-content/uploads/2017/11/cake-donuts-450x300.jpg"
      ],
      [
        "Baked Dessert Tarts",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-dessert-tarts-1-450x300.jpg"
      ]
    ]
  ],
  "bread": [
    "Bread",
    "Freshly baked bread",
    "🍞",
    [
      [
        "Sourdough Bread",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-bread-sourdough-1-450x300.jpg"
      ],
      [
        "Fresh Baked Bread",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-bread-baked-1-450x300.jpg"
      ],
      [
        "Baked Breads",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-baked-breads-1-450x300.jpg"
      ],
      [
        "Fresh Homemade Bread",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-bread-home-1-450x300.jpg"
      ],
      [
        "Bread Rolls",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-bread-rolls-1-450x300.jpg"
      ]
    ]
  ],
  "drinks": [
    "Drinks",
    "Coffee and refreshments",
    "☕",
    [
      [
        "Latte Art",
        "https://isorepublic.com/wp-content/uploads/2020/07/iso-republic-coffee-late-coffee-shop-369x300.jpg"
      ],
      [
        "Cappuccino in a Cafe",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-coffee-cup-cafe-1-450x300.jpg"
      ],
      [
        "Fresh Juice and Smoothies",
        "https://isorepublic.com/wp-content/uploads/2021/09/iso-republic-fresh-juices-and-smoothies-200x300.jpg"
      ],
      [
        "Iced Drink",
        "https://isorepublic.com/wp-content/uploads/2018/11/isorepublic-iced-drink-straw-1-450x300.jpg"
      ],
      [
        "Hot Chocolate",
        "https://isorepublic.com/wp-content/uploads/2019/05/iso-republic-hot-chocolates-453x300.jpg"
      ]
    ]
  ]
};

// Show either the category choices or the five photos for the selected category.
function setupGallery() {
  const grid = document.querySelector("#gallery-grid");
  if (!grid) return;

  const title = document.querySelector("#gallery-title");
  const description = document.querySelector("#gallery-description");
  const backLink = document.querySelector("#back-to-categories");
  const selectedCategory = new URLSearchParams(window.location.search).get("category");

  if (selectedCategory && galleryCategories[selectedCategory]) {
    const category = galleryCategories[selectedCategory];
    title.textContent = category[0];
    description.textContent = "Browse these five " + category[0].toLowerCase() + " photos. Select a picture to view it larger.";
    backLink.hidden = false;
    category[3].forEach(function (photo) {
      const card = document.createElement("button");
      card.className = "gallery-photo";
      card.type = "button";
      card.dataset.lightbox = photo[1];
      card.dataset.caption = photo[0];
      card.innerHTML = '<img loading="lazy" alt="' + photo[0].replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;") + '" src="' + photo[1] + '"><strong>' + photo[0] + '</strong>';
      card.querySelector("img").addEventListener("error", function () {
        this.alt = photo[0] + " photo could not be loaded. Check the internet connection.";
        this.classList.add("image-unavailable");
      });
      grid.appendChild(card);
    });
  } else {
    Object.keys(galleryCategories).forEach(function (key) {
      const category = galleryCategories[key];
      const link = document.createElement("a");
      link.className = "gallery-item";
      link.href = "gallery.html?category=" + key;
      link.innerHTML = '<span class="gallery-placeholder" aria-hidden="true">' + category[2] + '</span><strong>' + category[0] + '</strong><small>' + category[1] + '</small><small>View 5 photos →</small>';
      grid.appendChild(link);
    });
  }

  setupGalleryLightbox();
}

// Open any selected gallery photo in a larger dialog.
function setupGalleryLightbox() {
  const dialog = document.querySelector("#lightbox");
  const image = document.querySelector("#lightbox-image");
  const caption = document.querySelector("#lightbox-caption");
  const closeButton = document.querySelector(".lightbox-close");
  if (!dialog) return;

  document.querySelectorAll("[data-lightbox]").forEach(function (button) {
    button.addEventListener("click", function () {
      image.hidden = false;
      image.src = button.dataset.lightbox;
      image.alt = button.dataset.caption;
      caption.textContent = button.dataset.caption;
      image.onerror = function () {
        image.hidden = true;
        caption.textContent = button.dataset.caption + " — This photo could not be loaded. Check your internet connection.";
      };
      if (typeof dialog.showModal === "function") dialog.showModal();
    });
  });
  closeButton.addEventListener("click", function () { dialog.close(); });
  dialog.addEventListener("click", function (event) {
    if (event.target === dialog) dialog.close();
  });
}

// Show a clear message when the enquiry form is complete.
function setupEnquiryForm() {
  const form = document.querySelector("#enquiry-form");
  if (!form) return;

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    clearFormErrors(form);

    const name = form.elements.name.value.trim();
    const email = form.elements.email.value.trim();
    const product = form.elements.product.value;
    const quantity = Number(form.elements.quantity.value);
    let isValid = true;

    if (name.length < 2) isValid = showError("enquiry-name", "Please enter your name.");
    if (!isValid) { /* Keep checking other fields so all errors can be shown. */ }
    if (!isValidEmail(email)) {
      showError("enquiry-email", "Enter a valid email address.");
      isValid = false;
    }
    if (!product) {
      showError("product-type", "Please choose a product category.");
      isValid = false;
    }
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 100) {
      showError("quantity", "Choose a quantity from 1 to 100.");
      isValid = false;
    }

    const result = document.querySelector("#enquiry-result");
    if (!isValid) {
      result.hidden = true;
      return;
    }

    const details = form.elements.details.value.trim();
    result.textContent = "Thank you, " + name + ". Your enquiry is for " + quantity +
      " item(s) in the " + product + " category." +
      (details ? " Notes: " + details : "") +
      " This is not a confirmed order. Please contact the bakery to confirm price and availability.";
    result.hidden = false;
  });
}

// Validate the contact form and prepare an email in the visitor's email app.
function setupContactForm() {
  const form = document.querySelector("#contact-form");
  if (!form) return;

  form.addEventListener("submit", function (event) {
    event.preventDefault();
    clearFormErrors(form);

    const name = form.elements.name.value.trim();
    const email = form.elements.email.value.trim();
    const messageType = form.elements.messageType.value;
    const message = form.elements.message.value.trim();
    let isValid = true;

    if (name.length < 2) {
      showError("contact-name", "Please enter your name.");
      isValid = false;
    }
    if (!isValidEmail(email)) {
      showError("contact-email", "Enter a valid email address.");
      isValid = false;
    }
    if (!messageType) {
      showError("message-type", "Please choose a message type.");
      isValid = false;
    }
    if (message.length < 10) {
      showError("contact-message", "Please write at least 10 characters.");
      isValid = false;
    }

    const result = document.querySelector("#contact-result");
    if (!isValid) {
      result.hidden = true;
      return;
    }

    const subject = encodeURIComponent("Ora's Bakery - " + messageType);
    const body = encodeURIComponent(
      "Name: " + name + "\nEmail: " + email + "\nMessage type: " +
      messageType + "\n\nMessage:\n" + message
    );
    result.textContent = "Your details passed validation. Your email app should open with the message ready to send.";
    result.hidden = false;
    window.location.href = "mailto:info@orasbakery.co.za?subject=" + subject + "&body=" + body;
  });
}

// Add a helpful message beside invalid fields and focus the field.
function showError(fieldId, message) {
  const field = document.getElementById(fieldId);
  const errorMessage = document.getElementById(fieldId + "-error");
  if (field) {
    field.setAttribute("aria-invalid", "true");
    field.setAttribute("aria-describedby", fieldId + "-error");
    field.focus();
  }
  if (errorMessage) errorMessage.textContent = message;
  return false;
}

function clearFormErrors(form) {
  form.querySelectorAll("[aria-invalid='true']").forEach(function (field) {
    field.removeAttribute("aria-invalid");
    field.removeAttribute("aria-describedby");
  });
  form.querySelectorAll(".field-error").forEach(function (message) {
    message.textContent = "";
  });
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// When a visitor clicks "Enquire about cakes" on the menu page,
// preselect the category in the enquiry form.
function fillEnquiryFromLink() {
  const productSelect = document.querySelector("#product-type");
  if (!productSelect) return;

  const requestedItem = new URLSearchParams(window.location.search).get("item");
  if (requestedItem) {
    Array.from(productSelect.options).forEach(function (option) {
      if (option.value.toLowerCase() === requestedItem.toLowerCase() ||
          option.textContent.toLowerCase() === requestedItem.toLowerCase()) {
        productSelect.value = option.value || option.textContent;
      }
    });
  }
}
