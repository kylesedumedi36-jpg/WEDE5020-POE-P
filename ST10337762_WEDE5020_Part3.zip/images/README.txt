The gallery now loads 5 photos each for Cakes, Pastries, Bread and Drinks from ISO Republic image URLs.
The site needs an internet connection to display these photos. The photo source links are listed in js/script.js under galleryCategories.
For offline use, download images you are licensed to use and update the photo URLs to local images in this folder.
