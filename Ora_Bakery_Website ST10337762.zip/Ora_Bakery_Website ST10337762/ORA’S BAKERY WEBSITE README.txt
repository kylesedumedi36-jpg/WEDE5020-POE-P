ORA’S BAKERY WEBSITE README

1.  ABOUT THE PROJECT This is a simple first-year student website
    project for Ora’s Bakery.

The website is designed to introduce the bakery, show its products and
services, display bakery pictures, and allow visitors to make enquiries
or find the bakery.

2.  WEBSITE PAGES The website contains these pages:

-   index.html - Home page
-   about.html - Information about Ora’s Bakery
-   services.html - Bakery services
-   menu.html - Bakery menu and prices
-   gallery.html - Gallery of bakery pictures
-   enquiry.html - Enquiry form
-   contact.html - Contact details and locations
-   sitemap.html - List of website pages
-   sitemap.xml - Website sitemap for search engines

3.  FOLDERS The website uses the following folders:

css/ style.css This file contains the colours, layout, buttons, forms,
cards and responsive design used throughout the website.

images/ Contains the bakery pictures used on the Home, Menu and Gallery
pages.

4.  IMAGES The website uses the bakery pictures supplied for this
    project.

Images are linked from the HTML pages using code such as:

The images should remain inside the images folder. If an image is moved
or renamed, its HTML link must also be changed.

5.  WEBSITE NAVIGATION The pages are connected using the navigation menu
    at the top of each page.

For example:

Home About Services Menu Gallery Enquiry Contact

The Sitemap page also provides links to the main pages.

6.  COLOURS AND DESIGN The website uses a bakery-style colour scheme
    with brown, cream, orange and white colours.

The CSS also includes: - Responsive design for smaller screens -
Navigation links - Buttons - Product cards - Image styling - Forms -
Footer styling

7.  HOW TO OPEN THE WEBSITE

8.  Extract the Ora_Bakery_Website_Corrected.zip file.

9.  Open the extracted website folder.

10. Make sure the css and images folders are still inside the main
    folder.

11. Double-click index.html.

12. The website will open in a web browser.

13. Use the navigation menu to visit the other pages.

14. IMPORTANT Do not separate the HTML files from the css and images
    folders.

The website is a front-end website. The enquiry and contact forms are
included for the website design, but they do not have a database or
server-side system connected to them.

9.  STUDENT NOTE This project demonstrates basic first-year web
    development skills, including:

-   HTML page structure
-   Links between web pages
-   Images
-   CSS styling
-   Forms
-   Navigation
-   Responsive design
-   Website organisation
-   Sitemap creation

Created for the Ora’s Bakery website project.
